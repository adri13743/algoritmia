from __future__ import annotations

from dataclasses import dataclass

from board import RowCol
from direction import Direction


# dataclass: Brick
# Esta dataclass se encarga de gestionar los movimientos del bloque (prisma rectangular, ladrillo o brick)
#
# - Contine dos atributos del tipo RowCol, b1 y b2, con las posiciones de los dos cubos que forman
#   el bloque.
# - Para simplificar la implementación añadimos dos restriciones obligatorias:
#     - Cuando el bloque esté tumbado sobre una fila, b1 deberá ser el bloque de menor columna.
#     - Cuando el bloque esté tumbado sobre una columna, b1 deberá ser el bloque de menor fila.
# - Con estas dos restricciones un bloque debe cumplir una de estas tres condiciones:
#     b1.row == b2.row and b1.col == b2.col       # El boque está de pie
#     b1.row == b2.row and b1.col == b2.col - 1   # El boque está tumbado en una fila
#     b1.row == b2.row - 1 and b1.col == b2.col   # El boque está tumbado en una columna
# - Los objetos de esta clase son inmutables, por lo tanto, el método move() devuelve un nuevo bloque.
#
@dataclass(frozen=True)
class Brick:
    b1: RowCol
    b2: RowCol

    # El método __post_init__() es una ayuda para detectar bugs, se llama automáticamnte despues del constructor.
    # Comprueba que cada bloque que se construya cumpla una de las tres condiciones válidas
    def __post_init__(self):
        is_valid = self.b1.row == self.b2.row and self.b1.col == self.b2.col or \
                   self.b1.row == self.b2.row and self.b1.col == self.b2.col - 1 or \
                   self.b1.row == self.b2.row - 1 and self.b1.col == self.b2.col
        if not is_valid:
            raise RuntimeError(f"Built an invalid Brick (see restrictions): {self}")

    # Funcion para mover el bloque, como el bloque es inmutable el 'move' devuelve otro bloque
    def move(self, d: Direction) -> Brick:
        b1_row_new: int = 0
        b2_row_new: int = 0
        b1_col_new: int = 0
        b2_col_new: int = 0

        dir = d.value

        if self.esta_de_pie():                                                  # El bloque está de pie
            if dir == "U":                                                      # Dirección arriba
                b1_col_new = b2_col_new = self.b1.col                           # No se mueve de columna
                b1_row_new = self.b1.row - 2                                    # Cuadrado de abajo se mueve uno hacia arriba
                b2_row_new = self.b2.row - 1                                    # Cuadrado de arriba se mueve 2 hacia arriba

            elif dir == "D":                                                    # Direccion abajo
                b1_col_new = b2_col_new = self.b1.col                           # No se mueve de columna
                b1_row_new = self.b1.row + 1                                    # Cuadrado de abajo se mueve uno hacia abajo
                b2_row_new = self.b2.row + 2                                    # Cuadrado de arriba se mueve 2 hacia abajo

            elif dir == "R":                                                    # Direccion derecha
                b1_row_new = b2_row_new = self.b1.row                           # No se mueve de fila
                b1_col_new = self.b1.col + 1                                    # Cuadrado de abajo se mueve uno hacia derecha
                b2_col_new = self.b1.col + 2                                    # Cuadrado de arriba se mueve 2 hacia derecha

            else:                                                               # Direccion izquierda
                b1_row_new = b2_row_new = self.b1.row                           # No se mueve de fila
                b1_col_new = self.b1.col - 2                                    # Cuadrado de abajo se mueve uno hacia izquierda
                b2_col_new = self.b1.col - 1                                    # Cuadrado de arriba se mueve 2 hacia izquierda

        elif self.esta_tumbado_fila():                                          # El bloque está tumbado en una fila
            if dir == "U":                                                      # Dirección arriba
                b1_col_new = self.b1.col                                        # No se mueve de columna 1
                b2_col_new = self.b2.col                                        # No se mueve de columna 2
                b1_row_new = b2_row_new = self.b1.row - 1                       # El brick se mueve 1 (fila) hacia arriba

            elif dir == "D":                                                    # Direccion abajo
                b1_col_new = self.b1.col                                        # No se mueve de columna 1
                b2_col_new = self.b2.col                                        # No se mueve de columna 2
                b1_row_new = b2_row_new = self.b1.row + 1                       # El brick se mueve 1 (fila) hacia abajo

            elif dir == "R":                                                    # Direccion derecha
                b1_row_new = b2_row_new = self.b1.row                           # El brick no cambia de fila
                b1_col_new = b2_col_new = self.b2.col + 1                       # El brick se pone de pie y se mueve uno a la derecha

            else:                                                               # Direccion izquierda
                b1_row_new = b2_row_new = self.b1.row                           # El brick no cambia de fila
                b1_col_new = b2_col_new = self.b1.col - 1                       # El brick se pone de pie y se mueve uno a la izquierda

        else:                                                                   # El bloque está tumbado en una columna
            if dir == "U":                                                      # Dirección arriba
                b1_col_new = b2_col_new = self.b1.col                           # El brick no cambia de columna
                b1_row_new = b2_row_new = self.b1.row - 1                       # El brick se pone de pie y se mueve uno arriba

            elif dir == "D":                                                    # Dirección abajo
                b1_col_new = b2_col_new = self.b1.col                           # El brick no cambia de columna
                b1_row_new = b2_row_new = self.b2.row + 1                       # El brick se pone de pie y se mueve uno abajo

            elif dir == "R":                                                    # Direccion derecha
                b1_col_new = b2_col_new = self.b1.col + 1                       # El brick se mueve a la fila de la derecha
                b1_row_new = self.b1.row                                        # No cambia de fila
                b2_row_new = self.b2.row                                        # No cambia de fila

            else:                                                               # Direccion izquierda
                b1_col_new = b2_col_new = self.b1.col - 1                       # El brick se mueve a la fila de la izquierda
                b1_row_new = self.b1.row                                        # No cambia de fila
                b2_row_new = self.b2.row                                        # No cambia de fila

        return Brick(RowCol(b1_row_new, b1_col_new), RowCol(b2_row_new, b2_col_new)) #Devuelve un nuevo bloque

    def esta_de_pie(self) -> bool:
        return self.b1.row == self.b2.row and self.b1.col == self.b2.col

    def esta_tumbado_fila(self) -> bool:
        return self.b1.row == self.b2.row and self.b1.col == self.b2.col - 1